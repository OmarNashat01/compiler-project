## C compiler (compilers project)

### team members:
- Omar Alaa 1190377
- Omar Mostafa Fouad 1190430
- Rana Gamal 1190449

### Folder structure:
- `code/` contains the source code of the compiler.
- `tests/` contains the test cases for the compiler and output.asm.
